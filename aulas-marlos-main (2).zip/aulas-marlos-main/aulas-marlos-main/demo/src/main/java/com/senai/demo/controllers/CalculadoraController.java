package com.senai.demo.controllers;

import com.senai.demo.dtos.EntradaDto;
import com.senai.demo.dtos.ResultadoDto;
import com.senai.demo.service.CalculadoraService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/calculadora")
public class CalculadoraController {

    private final CalculadoraService service;
    public CalculadoraController(CalculadoraService service){
        this.service = service;
    }

    public ResponseEntity<ResultadoDto> adicionar(@RequestBody EntradaDto entrada){
    ResultadoDto resultado = service.adicionar(entrada);
    return ResponseEntity.ok().body(resultado);

    return ResponseEntity.ok().body(resultado);

}


}
