package com.senai.demo.service;


import com.senai.demo.dtos.EntradaDto;
import com.senai.demo.dtos.ResultadoDto;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

@Service
public class CalculadoraService {

    @PostMapping
    public double adicionar(EntradaDto entrada){
        ResultadoDto resultado = new ResultadoDto();
        resultado.setN1(entrada.getN1());
        resultado.setN2(entrada.getN2());
        resultado.setResultado(entrada.getN1() + entrada.getN2());
        return resultado = ;

    }

}
